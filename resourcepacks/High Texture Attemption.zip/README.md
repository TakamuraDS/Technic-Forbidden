### MC-New-Textures-(Version required to run: 1.7.10--1.13.2)
This is the new version of the texture pack for Minecraft. It is based on the Minecraft texture of 1.14 and later. Thank you for using it. (Version required to run: 1.7.10--1.13.2)
Download at 
[GitHub](https://github.com/song682/MC-New-Textures)
[Modrinth](https://modrinth.com/resourcepack/minecraft-new-textures)
Create by dfdvdsf.
Under MIT License[License]